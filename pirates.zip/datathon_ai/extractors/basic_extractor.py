from typing import List

from datathon_ai.interfaces import FormDataModel, QuestionResponse
from .question_extractor import QuestionExtractor
from .utils import get_dico_dummy_answers

class BasicExtractor(QuestionExtractor):
    def __init__(self, question_ids: List[int], form_data_model: FormDataModel):
        super().__init__(question_ids, form_data_model)

    def extract(self, text: str) -> List[QuestionResponse]:
        responses = []
        for question_id in self.question_ids:
            answer, question_id, justification = self.predict_dummy(text, question_id)
            responses.append(
                QuestionResponse(answer_id=answer, question_id=question_id, justification=justification)
            )
        return responses
    
    def predict_dummy(self, text, question_id) :
        if not hasattr(self, 'dico_dummy_answers') :
            self.dico_dummy_answers = get_dico_dummy_answers()
        return self.dico_dummy_answers[question_id], question_id, "YOLO"
        